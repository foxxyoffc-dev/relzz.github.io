let broadcastTimeout = null;

function startAutoBroadcast(Elaina) {
  if (broadcastTimeout) return; // Cegah dobel timeout

  async function sendBroadcast() {
    try {
      const allGroups = await Elaina.groupFetchAllParticipating();
      const groupIds = Object.keys(allGroups);

      const now = new Date();
      const jam = now.getHours().toString().padStart(2, '0');
      const menit = now.getMinutes().toString().padStart(2, '0');

      const text = `💫 OPEN SEWA BOT WHATSAPP - AUTO SYSTEM 💫
🔥 Powered by Elaina Multi-Feature WA Bot 🔥

🔧 Fitur Unggulan:
✅ Menu lengkap (sticker, downloader, ai, dll)
✅ Mode public/self
✅ Anti delete + welcome/left
✅ Bisa request custom fitur

🎉 Melihat List All Sewa 🎉
[ *.sewa* ]

🎯 Bot bisa masuk ke grup kamu sekarang juga!
📍 Bayar via Dana / QRIS / Gooay

📬 Minat? Chat admin sekarang!
👉 wa.me/6285189511338
🛡️ Sistem Otomatis, Aman & Cepat!`;

      for (let id of groupIds) {
        await Elaina.sendMessage(id, { text });
      }

      console.log(`[AutoBroadcast] Terkirim ke ${groupIds.length} grup pada ${jam}:${menit}`);
    } catch (err) {
      console.error('[AutoBroadcast Error]', err);
    }

    // Random interval berikutnya antara 1–3 jam (dalam ms)
    const nextDelay = (Math.floor(Math.random() * (3 - 1 + 1)) + 1) * 60 * 60 * 1000;
    broadcastTimeout = setTimeout(sendBroadcast, nextDelay);
  }

  sendBroadcast(); // Mulai segera
}

function stopAutoBroadcast() {
  if (broadcastTimeout) {
    clearTimeout(broadcastTimeout);
    broadcastTimeout = null;
    console.log('[AutoBroadcast] Dihentikan.');
  }
}

module.exports = { startAutoBroadcast, stopAutoBroadcast };
